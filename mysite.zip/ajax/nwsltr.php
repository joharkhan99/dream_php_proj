<?php include "functions.php" ?>
<?php
if (isset($_POST['email']) && !empty($_POST['email'])) {

  $email = sanitize($_POST['email']);

  if (empty($email)) {
    echo "Please provide an Email Address0";
  }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      echo("$email is not a valid email address0");
  } elseif (!NewsLetter($email)) {
    echo "Error adding your email. Maybe try again0";
  }else{
      echo "Subscribed Successfully!";
  }
} else {
    echo "Please provide an Email Address0";
}