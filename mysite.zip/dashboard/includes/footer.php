<?php
include_once "../ajax/functions.php";
checkIfLogin();
?>
<!-- Footer -->
<footer class="sticky-footer bg-white mt-5">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>Copyright © Your Website <?php echo date('Y'); ?></span>
    </div>
  </div>
</footer>
<!-- End of Footer -->