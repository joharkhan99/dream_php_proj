<?php
include_once "../ajax/functions.php";
checkIfLogin();
?>
<!DOCTYPE html>
<html lang="en">

<head>
      <title><?php getuserinfo($_COOKIE['_uacct_'], 'name') ?> - Likhdy Dashboard</title>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1,maximum-scale=1" />
    <meta name="theme-color" content="#3158c9" />
    <meta property="og:site_name" content="Likhdy" />
    <link rel="apple-touch-icon" href="https://likhdy.com/img/likhdy-white-logo.PNG" />
    <link rel="icon" type="image/x-icon" href="https://likhdy.com/img/likhdy-white-logo.PNG">
    <meta name="robots" content="index,follow,max-image-preview:large" />
    <link rel="preconnect" href="https://likhdy.com" crossOrigin="" />
    <meta name="title" content="Likhdy Dashboard | Write your own thoughts and ideas and share with the world" />
    <meta property="og:title" content="Likhdy Dashboard | Write your own thoughts and ideas and share with the world" />
    <meta name="description" content="Likhdy is an open platform wherein readers find dynamic wondering, and in which professional and undiscovered voices can proportion their writing on any subject or matter." />
    <meta property="og:description" content="Likhdy is an open platform wherein readers find dynamic wondering, and in which professional and undiscovered voices can proportion their writing on any subject or matter." />
    <meta name="keywords" content="Likhdy, free article writing, article information, free blogs, free posts, read articles,write freely, articles on any subject, professional writing community, likhdy articles, likhdy blogs, write on likhdy" />
    <meta property="og:url" content="https://likhdy.com/dashboard/index" />
    <meta property="al:web:url" content="https://likhdy.com/dashboard/index" />
    <meta property="og:image" content="https://likhdy.com/img/likhdy-white-logo.PNG" />
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <link rel="canonical" href="https://likhdy.com/dashboard/index" />
  
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">

  <link rel="stylesheet" href="css/sb-admin-2.min.css">
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400&display=swap" rel="stylesheet">
</head>

<body id="page-top">