<?php include "includes/header.php" ?>
<div id="wrapper">

  <?php include "includes/sidebar.php" ?>

  <!-- Content Wrapper -->
  <div id="content-wrapper" class="d-flex flex-column">
    <!-- Main Content -->
    <div id="content">

      <?php include "includes/topbar.php" ?>


      <!-- Begin Page Content -->
      <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
        </div>

        <!-- Content Row -->
        <div class="row">

          <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
              <div class="card-body">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Articles</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php getusertotalposts($_COOKIE['_uacct_']); ?></div>
                  </div>
                  <div class="col-auto">
                    <i class="fas fa-newspaper fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
              <div class="card-body">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Drafts</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php getusertotalposts($_COOKIE['_uacct_'], 'draft'); ?></div>
                  </div>
                  <div class="col-auto">
                    <i class="fas fa-file-signature fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
              <div class="card-body">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Views</div>
                    <div class="row no-gutters align-items-center">
                      <div class="col-auto">
                        <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php getusertotalviews($_COOKIE['_uacct_']) ?></div>
                      </div>
                    </div>
                  </div>
                  <div class="col-auto">
                    <i class="fas fa-book-reader fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
              <div class="card-body">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Total Comments</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php getusertotalcomments($_COOKIE['_uacct_']) ?></div>
                  </div>
                  <div class="col-auto">
                    <i class="fas fa-comments fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-6">

            <div class="row">

              <div class="col-md-6 mb-2">
                <div class="card gradient-1 custom-shadow1 h-100 py-2">
                  <a href="published" class="d-block text-decoration-none text-white">
                    <div class="card-body">
                      <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                          <div class="h5 mb-2 font-weight-bold">View Published</div>
                          <div class="text-xs mb-0 font-weight-bold text-uppercase">click for details</div>
                        </div>
                        <div class="col-auto">
                          <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
              </div>

              <div class="col-md-6 mb-2">
                <div class="card gradient-2 custom-shadow1 h-100 py-2">
                  <a href="write-article" class="d-block text-decoration-none text-white">
                    <div class="card-body">
                      <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                          <div class="h5 mb-2 font-weight-bold">Publish An Article</div>
                          <div class="text-xs mb-0 font-weight-bold text-uppercase">click to add</div>
                        </div>
                        <div class="col-auto">
                          <i class="fas fa-feather-alt fa-2x text-gray-300"></i>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
              </div>

              <div class="col-md-6 mb-2">
                <div class="card gradient-3 custom-shadow1 h-100 py-2">
                  <a href="draft" class="d-block text-decoration-none text-white">
                    <div class="card-body">
                      <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                          <div class="h5 mb-2 font-weight-bold">View Drafts</div>
                          <div class="text-xs mb-0 font-weight-bold text-uppercase">click for details</div>
                        </div>
                        <div class="col-auto">
                          <i class="fas fa-file-signature fa-2x text-gray-300"></i>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
              </div>

              <div class="col-md-6 mb-2">
                <div class="card gradient-4 custom-shadow1 h-100 py-2">
                  <a href="comments" class="d-block text-decoration-none text-white">
                    <div class="card-body">
                      <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                          <div class="h5 mb-2 font-weight-bold">View Comments</div>
                          <div class="text-xs mb-0 font-weight-bold text-uppercase">click for details</div>
                        </div>
                        <div class="col-auto">
                          <i class="fas fa-comments fa-2x text-gray-300"></i>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
              </div>

              <div class="col-md-6 mb-2">
                <div class="card gradient-5 custom-shadow1 h-100 py-2">
                  <a href="settings" class="d-block text-decoration-none text-white">
                    <div class="card-body">
                      <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                          <div class="h5 mb-2 font-weight-bold">Profile Settings</div>
                          <div class="text-xs mb-0 font-weight-bold text-uppercase">click for details</div>
                        </div>
                        <div class="col-auto">
                          <i class="fas fa-user-cog fa-2x text-gray-300"></i>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
              </div>

            </div>

          </div>

          <!-- recent comments -->
          <div class="col-md-6">

            <div class="comments bg-white px-3 py-3 rounded shadow-sm">
              <h5 class="border-bottom py-2 mb-4">Recent comments on your articles</h5>

              <?php getDashboardComments($_COOKIE['_uacct_']) ?>

            </div>
          </div>

        </div>

      </div>
      <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->


    <?php include "includes/footer.php" ?>
  </div>
  <!-- End of Content Wrapper -->

</div>


<?php include "includes/scripts.php" ?>