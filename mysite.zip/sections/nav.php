<header class="shadow">
  <nav class="navbar navbar-expand-lg" aria-label="Eighth navbar example">
    <div class="container-lg">

      <a class="navbar-brand" href="index">
<img src="img/likhdy-logo.PNG" style="width: 53px;" alt="Likhdy logo, likhdy black logo">
      </a>

      <div class="collapse navbar-collapse" id="navbarsExample07">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link" href="explore">Explore</a>
          </li>
          <?php if (empty($_COOKIE["_uacct_"]) || !isset($_COOKIE["_uacct_"])) : ?>
            <li class="nav-item">
              <a class="nav-link" href="login">Sign In</a>
            </li>
            <li class="nav-item">
              <a class="nav-link btn btn-primary text-white rounded" href="signup">Create account</a>
            </li>
          <?php endif; ?>

        </ul>
      </div>

      <?php if (!empty($_COOKIE["_uacct_"]) && isset($_COOKIE["_uacct_"])) : ?>
        <?php if (userKeyExists($_COOKIE["_uacct_"])) : ?>
          <div class="dropdown home-user-btn">
            <button type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
              <img src="users/<?php echo getuserinfo($_COOKIE["_uacct_"], 'profile_pic') ?>" alt="" class="shadow-sm">
            </button>
            <ul class="dropdown-menu shadow border-0" aria-labelledby="dropdownMenuButton1">
              <li><a class="dropdown-item" href="dashboard/index">Dashboard</a></li>
              <li><a class="dropdown-item" href="logout">Log out</a></li>
            </ul>
            <style>
              .home-user-btn .dropdown-menu {
                right: 10px;
                left: unset;
              }

              .home-user-btn .dropdown-menu .dropdown-item {
                font-size: 14px;
              }

              .home-user-btn {
                margin-right: 50px;
              }

              .home-user-btn button {
                background: none;
                border: none;
                outline: none;
              }

              .home-user-btn button img {
                width: 35px;
                height: 35px;
                border-radius: 50%;
                object-fit: cover;
              }

              .home-user-btn img {
                object-fit: cover;
              }
            </style>
          </div>
        <?php endif; ?>
      <?php endif; ?>

    </div>
  </nav>

  <div class="mobile-nav">
    <div id="body-overlay" onclick="toggleMenu()"></div>
    <nav class="real-menu" role="navigation">
      <ul>
        <button class="close_btn" onclick="toggleMenu()">
          <span></span>
          <span></span>
        </button>
        <li><a href="index" class="d-block py-2">home</a></li>
        <li><a href="explore" class="d-block py-2">Explore</a></li>
        
                  <?php if (empty($_COOKIE["_uacct_"]) || !isset($_COOKIE["_uacct_"])) : ?>
        <li class="menu-btn menu-btn-2 shadow text-center mt-5"><a href="login" class="d-block py-2">Sign In</a></li>
        <li class="menu-btn shadow text-center"><a href="signup" class="d-block py-2">Create account</a></li>
      <?php endif; ?>
        
        <?php if (!empty($_COOKIE["_uacct_"]) && isset($_COOKIE["_uacct_"])) : ?>
        <?php if (userKeyExists($_COOKIE["_uacct_"])) : ?>
                <li class="menu-btn shadow text-center"><a href="dashboard/index" class="d-block py-2">Dashboard</a></li>
      <?php endif; ?>
      <?php endif; ?>
        
      </ul>
    </nav>
    <button id="open-mob-menu" onclick="toggleMenu()">
      <span></span>
      <span class="w-75"></span>
      <span></span>
    </button>
  </div>
</header>