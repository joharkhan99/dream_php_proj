<div class="container newsletter">
  <div class="row">
    <div class="col-md-11 mx-auto">
      <div class="heading">Subscribe for Latest Updates!</div>
      <form action="" id="newsletter_form" onsubmit="event.preventDefault();Nwsletter()" method="POST">

        <div class="form-group">
          <input type="email" name="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter your email" required>
          <small id="emailHelp" class="form-text text-muted">* We'll never share your email with anyone
            else.</small>
          <button type="submit"><i class="fas fa-check"></i></button>
        </div>

      </form>
    </div>
  </div>
</div>