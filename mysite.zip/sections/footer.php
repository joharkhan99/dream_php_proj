<footer>
  <div class="container-fluid">
    <div class="row social">
    <!--  <ul>-->
    <!--    <li><a href="javascript:void(0)"><i class="fab fa-facebook-f"></i></a></li>-->
    <!--    <li><a href="javascript:void(0)"><i class="fab fa-twitter"></i></a></li>-->
    <!--    <li><a href="javascript:void(0)"><i class="fab fa-instagram"></i></a></li>-->
    <!--    <li><a href="javascript:void(0)"><i class="fab fa-youtube"></i></a></li>-->
    <!--    <li><a href="javascript:void(0)"><i class="fab fa-linkedin-in"></i></a></li>-->
    <!--  </ul>-->
    <!--</div>-->

    <!--<div class="footer_links">-->
    <!--  <ul>-->
    <!--    <li><a href="javascript:void(0)">Login</a></li>-->
    <!--    <li><a href="javascript:void(0)">Internet</a></li>-->
    <!--    <li><a href="javascript:void(0)">Funny</a></li>-->
    <!--    <li><a href="javascript:void(0)">Advertisement</a></li>-->
    <!--    <li><a href="javascript:void(0)">Advertisement</a></li>-->
    <!--    <li><a href="javascript:void(0)">Advertisement</a></li>-->
    <!--    <li><a href="javascript:void(0)">Advertisement</a></li>-->
    <!--    <li><a href="javascript:void(0)">Contact</a></li>-->
    <!--    <li><a href="javascript:void(0)">About</a></li>-->
    <!--  </ul>-->
    <!--</div>-->

    <div class="cp">
      <span>
        &copy;
        <script>
          document.write(new Date().getFullYear());
        </script>
        <a href="https://likhdy.com/">Likhdy</a>
      </span>
    </div>

  </div>
</footer>