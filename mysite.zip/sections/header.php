<!DOCTYPE html>
<html lang="en">
<head>
<?php include "ajax/functions.php" ?>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1,maximum-scale=1" />
    <meta name="theme-color" content="#3158c9" />
    <meta property="og:site_name" content="Likhdy" />
    <link rel="apple-touch-icon" href="https://likhdy.com/img/likhdy-white-logo.PNG" />
    <link rel="icon" type="image/x-icon" href="https://likhdy.com/img/likhdy-white-logo.PNG">
    <meta name="robots" content="index,follow,max-image-preview:large" />
    <link rel="preconnect" href="https://likhdy.com" crossOrigin="" />
<?php
$pagename = basename($_SERVER['PHP_SELF']);
switch ($pagename) {
  case "index.php":
    getIndexMeta();
    break;
  case "categories.php":
    if (isset($_GET['category']) && !empty($_GET['category'])) {
      $category = categoryURLUnslug($_GET['category']);
      getCategoryMeta(sanitize($category));
    }
    break;
  case "tag.php":
    if (isset($_GET['tag']) && !empty($_GET['tag'])) {
      $tag = categoryURLUnslug($_GET['tag']);
      getTagMeta($tag);
    }
    break;
  case "author.php":
    if (isset($_GET['author']) && !empty($_GET['author']) && isset($_GET['i']) && !empty($_GET['i'])) {
      $authorname = $_GET['author'];
      $userkey = $_GET['i'];
      getAuthorMeta(categoryURLUnslug($authorname), $userkey);
    }
    break;
  case "login.php":
    getLoginMeta();
    break;
  case "signup.php":
    getSignUpMeta();
    break;
  case "explore.php":
    getExploreMeta();
    break;
  case "article.php":
    if (isset($_GET['i']) && !empty($_GET['i'])) {
      $post_id = sanitize($_GET['i']);
      getArticleMeta($post_id);
      break;
    }
  default:
    getIndexMeta();
    break;
}
?>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css?v=<?php echo time() ?>">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

</head>

<body>